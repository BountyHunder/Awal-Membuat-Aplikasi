package com.example.muhamadabdullahabdurfarid2311500181;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private EditText edtnamapel, edtnamabar, edtjumlahbel, edtharga, edtuangbay;
    private Button btnproses;
    private Button btnhapus;
    private Button btnexit;
    private TextView txtbonus;
    private TextView txttotalbelanja;
    private TextView txtuangkembali;
    private TextView txtketerangan;

    // For formatting currency values
    private NumberFormat currencyFormat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try {
            getSupportActionBar().setTitle("Badoy Shop");
        } catch (NullPointerException e) {
            // Handle case where ActionBar might not be available
        }

        // Set up currency formatter
        currencyFormat = NumberFormat.getCurrencyInstance(new Locale("in", "ID"));

        // Initialize EditText fields
        edtnamapel = findViewById(R.id.namapelanggan);
        edtnamabar = findViewById(R.id.namabarang);
        edtjumlahbel = findViewById(R.id.jumlahbeli);
        edtharga = findViewById(R.id.harga);
        edtuangbay = findViewById(R.id.uangbayar);

        // Initialize Buttons
        btnproses = findViewById(R.id.tombol1);
        btnhapus = findViewById(R.id.tombol2);
        btnexit = findViewById(R.id.tombol3);

        // Initialize TextViews
        txtbonus = findViewById(R.id.bonus);
        txttotalbelanja = findViewById(R.id.totalbelanja);
        txtuangkembali = findViewById(R.id.uangkembali);
        txtketerangan = findViewById(R.id.keterangan);

        // Initialize default values for TextViews
        txttotalbelanja.setText("Total Belanja : Rp 0");
        txtuangkembali.setText("Uang Kembali : Rp 0");
        txtbonus.setText("Bonus : -");
        txtketerangan.setText("Keterangan : -");

        // Action for Process button
        btnproses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Validate input fields
                if (edtnamapel.getText().toString().trim().isEmpty() ||
                        edtnamabar.getText().toString().trim().isEmpty() ||
                        edtjumlahbel.getText().toString().trim().isEmpty() ||
                        edtharga.getText().toString().trim().isEmpty() ||
                        edtuangbay.getText().toString().trim().isEmpty()) {

                    Toast.makeText(getApplicationContext(), "Semua field harus diisi", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    String namapelanggan = edtnamapel.getText().toString().trim();
                    String namabarang = edtnamabar.getText().toString().trim();
                    String jumlahbeli = edtjumlahbel.getText().toString().trim();
                    String harga = edtharga.getText().toString().trim();
                    String uangbayar = edtuangbay.getText().toString().trim();

                    double jb = Double.parseDouble(jumlahbeli);
                    double h = Double.parseDouble(harga);
                    double ub = Double.parseDouble(uangbayar);
                    double total = (jb * h);

                    // Format currency with Rupiah symbol
                    String formattedTotal = "Total Belanja : " + formatRupiah(total);
                    txttotalbelanja.setText(formattedTotal);

                    // Bonus logic (higher amounts get better bonuses)
                    if (total >= 200000) {
                        txtbonus.setText("Bonus : Harddisk");
                    } else if (total >= 50000) {
                        txtbonus.setText("Bonus : Keyboard");
                    } else if (total >= 40000) {
                        txtbonus.setText("Bonus : Mouse");
                    } else {
                        txtbonus.setText("Bonus : Tidak Ada Bonus");
                    }

                    double uangkembalian = (ub - total);
                    if (ub < total) {
                        txtketerangan.setText("Keterangan : uang bayar kurang " + formatRupiah(-uangkembalian));
                        txtuangkembali.setText("Uang Kembali : Rp 0");
                    } else {
                        txtketerangan.setText("Keterangan : Tunggu Kembalian");
                        txtuangkembali.setText("Uang Kembali : " + formatRupiah(uangkembalian));
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(getApplicationContext(), "Format angka tidak valid", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Terjadi kesalahan: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Action for Reset button
        btnhapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Clear EditText fields properly
                edtnamapel.setText("");
                edtnamabar.setText("");
                edtjumlahbel.setText("");
                edtharga.setText("");
                edtuangbay.setText("");

                // Reset TextViews to default values
                txttotalbelanja.setText("Total Belanja : Rp 0");
                txtuangkembali.setText("Uang Kembali : Rp 0");
                txtbonus.setText("Bonus : -");
                txtketerangan.setText("Keterangan : -");

                Toast.makeText(getApplicationContext(), "Data sudah direset", Toast.LENGTH_LONG).show();
            }
        });

        // Action for Exit button
        btnexit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                moveTaskToBack(true);
            }
        });
    }

    // Helper method to format currency values
    private String formatRupiah(double amount) {
        return "Rp " + String.format("%,.0f", amount);
    }
}